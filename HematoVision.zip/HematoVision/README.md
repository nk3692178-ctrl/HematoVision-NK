# 🔬 HematoVision — AI Blood Cell Classifier

Advanced blood cell classification using Transfer Learning (MobileNetV2) with Flask backend and HL7 FHIR R4 clinical report generation.

---

## 📁 Project Structure

```
HematoVision/
├── app.py                        # Flask backend (inference + FHIR)
├── train.py                      # Model training script
├── requirements.txt              # Python dependencies
├── Dockerfile                    # Docker deployment config
├── model/
│   └── hematovision_v1.h5       # Trained model (place here after training)
├── static/
│   ├── css/style.css            # Frontend stylesheet
│   └── uploads/                 # Uploaded images (auto-created)
└── templates/
    ├── index.html               # Upload page
    └── result.html              # Diagnostic result page
```

---

## ⚡ Quick Start (Local)

### 1. Clone & Setup
```bash
git clone <your-repo>
cd HematoVision
python -m venv venv
source venv/bin/activate         # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Get the Dataset
Download the **Kaggle Blood Cell Detection Dataset** (~12,500 images):
- https://www.kaggle.com/datasets/paultimothymooney/blood-cells

Extract into a `dataset/` folder with structure:
```
dataset/
├── TRAIN/
│   ├── EOSINOPHIL/
│   ├── LYMPHOCYTE/
│   ├── MONOCYTE/
│   └── NEUTROPHIL/
└── TEST/
    └── ...
```

### 3. Train the Model
```bash
python train.py
# Model saved to model/hematovision_v1.h5 after training
```

### 4. Run the App
```bash
python app.py
# Visit http://localhost:5000
```

> **Demo Mode**: If no trained model is found, the app runs in demo mode with random predictions so you can still test the UI.

---

## 🐳 Docker Deployment

```bash
# Build image
docker build -t hematovision .

# Run container
docker run -p 5000:5000 hematovision
```

---

## ☁️ Cloud Deployment

### Render.com (Free Tier)
1. Push to GitHub
2. Create new **Web Service** on Render
3. Set build command: `pip install -r requirements.txt`
4. Set start command: `python app.py`

### Railway / Fly.io
Use the provided `Dockerfile` — just connect your GitHub repo.

---

## 🔌 REST API

The app also exposes a JSON API:

```bash
curl -X POST http://localhost:5000/api/predict \
  -F "file=@blood_cell.jpg"
```

Response:
```json
{
  "prediction": "Neutrophil",
  "confidence": 94.32,
  "all_probabilities": {
    "Eosinophil": 1.2,
    "Lymphocyte": 2.1,
    "Monocyte": 2.38,
    "Neutrophil": 94.32
  },
  "cell_info": { ... },
  "fhir_observation": { ... }
}
```

Health check: `GET /health`

---

## 🧠 Model Architecture

| Component | Details |
|-----------|---------|
| Base Model | MobileNetV2 (ImageNet pre-trained) |
| Input Size | 224 × 224 × 3 |
| Classes | Eosinophil, Lymphocyte, Monocyte, Neutrophil |
| Head | GAP → Dense(256) → BN → Dropout(0.5) → Dense(128) → Softmax(4) |
| Training | 2-phase: frozen backbone → fine-tune top 20 layers |
| Augmentation | Rotation, shift, zoom, flip |

---

## ⚕️ Disclaimer

This tool is for **research and educational purposes only**. Results must be reviewed by a qualified pathologist before clinical use.

---

## 📚 References
- BCCD Dataset: https://github.com/Shenggan/BCCD_Dataset
- MobileNetV2: https://arxiv.org/abs/1801.04381
- HL7 FHIR R4: https://www.hl7.org/fhir/
