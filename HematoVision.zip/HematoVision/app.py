"""
HematoVision - Flask Backend
Blood Cell Classification API with HL7 FHIR Integration
"""

import os
import uuid
import numpy as np
import cv2
from datetime import datetime
from flask import Flask, request, render_template, jsonify, redirect, url_for
from werkzeug.utils import secure_filename

# ─── Try loading TensorFlow (graceful fallback for demo mode) ──────────────────
try:
    from tensorflow.keras.models import load_model
    TF_AVAILABLE = True
except ImportError:
    TF_AVAILABLE = False
    print("[WARNING] TensorFlow not found. Running in DEMO mode.")

# ─── App Config ───────────────────────────────────────────────────────────────
app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = os.path.join("static", "uploads")
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16MB max
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "bmp", "tiff"}

os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

# ─── Classes & Model ──────────────────────────────────────────────────────────
CLASSES = ["Eosinophil", "Lymphocyte", "Monocyte", "Neutrophil"]

CLASS_INFO = {
    "Eosinophil": {
        "role": "Fights parasites and mediates allergic reactions",
        "normal_range": "1–4% of WBCs",
        "associated_conditions": "Allergies, Asthma, Parasitic infections, Eosinophilia",
        "color": "#FF6B6B"
    },
    "Lymphocyte": {
        "role": "Core of adaptive immunity; B-cells and T-cells",
        "normal_range": "20–40% of WBCs",
        "associated_conditions": "Viral infections, Lymphoma, HIV, Leukemia (ALL/CLL)",
        "color": "#4ECDC4"
    },
    "Monocyte": {
        "role": "Phagocytosis and antigen presentation",
        "normal_range": "2–8% of WBCs",
        "associated_conditions": "Bacterial infections, Tuberculosis, Inflammatory diseases",
        "color": "#FFE66D"
    },
    "Neutrophil": {
        "role": "First responder to bacterial and fungal infections",
        "normal_range": "55–70% of WBCs",
        "associated_conditions": "Bacterial infections, Sepsis, Neutropenia, AML",
        "color": "#A8E6CF"
    }
}

# ─── Load Model ───────────────────────────────────────────────────────────────
model = None
MODEL_PATH = "model/hematovision_v1.h5"

if TF_AVAILABLE and os.path.exists(MODEL_PATH):
    try:
        model = load_model(MODEL_PATH)
        print(f"[✅] Model loaded from {MODEL_PATH}")
    except Exception as e:
        print(f"[ERROR] Could not load model: {e}")
else:
    print("[INFO] No model file found. Using demo predictions.")

# ─── Helpers ──────────────────────────────────────────────────────────────────
def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def preprocess_image(img_path):
    """Resize, convert color space, normalize."""
    img = cv2.imread(img_path)
    if img is None:
        raise ValueError("Could not read image.")
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (224, 224))
    img = img.astype("float32") / 255.0
    return np.expand_dims(img, axis=0)


def run_inference(img_path):
    """Return (label, confidence_pct, all_probs_dict)."""
    if model is not None:
        processed = preprocess_image(img_path)
        preds = model.predict(processed, verbose=0)[0]
    else:
        # Demo mode: random realistic predictions
        preds = np.random.dirichlet(np.ones(4) * 2)

    idx = int(np.argmax(preds))
    label = CLASSES[idx]
    confidence = float(preds[idx]) * 100
    all_probs = {cls: round(float(p) * 100, 2) for cls, p in zip(CLASSES, preds)}
    return label, confidence, all_probs


def generate_fhir_observation(label, confidence, patient_id=None):
    """Generate an HL7 FHIR R4 Observation resource."""
    now = datetime.utcnow().isoformat() + "Z"
    obs_id = str(uuid.uuid4())[:8]
    return {
        "resourceType": "Observation",
        "id": obs_id,
        "status": "final",
        "category": [
            {
                "coding": [
                    {
                        "system": "http://terminology.hl7.org/CodeSystem/observation-category",
                        "code": "laboratory",
                        "display": "Laboratory"
                    }
                ]
            }
        ],
        "code": {
            "coding": [
                {
                    "system": "http://loinc.org",
                    "code": "58413-6",
                    "display": "Differential Blood Count"
                }
            ],
            "text": "Blood Cell Classification (AI-assisted)"
        },
        "subject": {"reference": f"Patient/{patient_id or 'anonymous'}"},
        "effectiveDateTime": now,
        "performer": [{"display": "HematoVision AI v1.0"}],
        "valueString": f"{label}",
        "interpretation": [
            {
                "coding": [
                    {
                        "system": "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
                        "code": "N",
                        "display": "Normal"
                    }
                ]
            }
        ],
        "note": [
            {
                "text": f"AI Classification: {label} with {confidence:.1f}% confidence. "
                        f"This result is AI-assisted and should be reviewed by a qualified pathologist."
            }
        ],
        "device": {"display": "HematoVision Transfer Learning Model (MobileNetV2)"}
    }


# ─── Routes ───────────────────────────────────────────────────────────────────
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    if "file" not in request.files:
        return redirect(url_for("home"))

    f = request.files["file"]
    if f.filename == "" or not allowed_file(f.filename):
        return render_template("index.html", error="Please upload a valid image (JPG, PNG, BMP, TIFF).")

    try:
        # Save file securely
        ext = f.filename.rsplit(".", 1)[1].lower()
        filename = f"{uuid.uuid4().hex}.{ext}"
        filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        f.save(filepath)

        # Run inference
        label, confidence, all_probs = run_inference(filepath)
        info = CLASS_INFO[label]
        fhir = generate_fhir_observation(label, confidence)

        return render_template(
            "result.html",
            label=label,
            confidence=round(confidence, 2),
            all_probs=all_probs,
            info=info,
            img_path=filepath,
            fhir=fhir,
            timestamp=datetime.now().strftime("%B %d, %Y at %H:%M UTC")
        )

    except Exception as e:
        return render_template("index.html", error=f"Analysis failed: {str(e)}")


@app.route("/api/predict", methods=["POST"])
def api_predict():
    """JSON API endpoint for programmatic access."""
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    f = request.files["file"]
    if not allowed_file(f.filename):
        return jsonify({"error": "Invalid file type"}), 400

    try:
        ext = f.filename.rsplit(".", 1)[1].lower()
        filename = f"{uuid.uuid4().hex}.{ext}"
        filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        f.save(filepath)

        label, confidence, all_probs = run_inference(filepath)
        fhir = generate_fhir_observation(label, confidence)

        return jsonify({
            "prediction": label,
            "confidence": round(confidence, 2),
            "all_probabilities": all_probs,
            "cell_info": CLASS_INFO[label],
            "fhir_observation": fhir
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/health")
def health():
    return jsonify({
        "status": "ok",
        "model_loaded": model is not None,
        "tf_available": TF_AVAILABLE,
        "version": "1.0.0"
    })


# ─── Run ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
